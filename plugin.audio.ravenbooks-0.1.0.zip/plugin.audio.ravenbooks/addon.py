# -*- coding: utf-8 -*-
# Raven Books - story library with cloud TTS (Google) for Kodi 21 (Omega)
import os
import re
import sys
import time
import urllib.error
import urllib.parse
import urllib.request

import xbmc
import xbmcaddon
import xbmcgui
import xbmcplugin
import xbmcvfs

ADDON = xbmcaddon.Addon()
HANDLE = int(sys.argv[1])
BASE_URL = sys.argv[0]
ADDON_PATH = ADDON.getAddonInfo("path")
STORIES_DIR = os.path.join(ADDON_PATH, "resources", "stories")
CACHE_DIR = os.path.join(
    xbmcvfs.translatePath(ADDON.getAddonInfo("profile")), "cache")

MAX_CHARS = 180      # Google TTS limit is about 200 characters per request
START_CHUNKS = 2     # convert this many chunks before playback starts
USER_AGENT = ("Mozilla/5.0 (Linux; Android 10) AppleWebKit/537.36 "
              "(KHTML, like Gecko) Chrome/120.0 Mobile Safari/537.36")


def log(msg):
    xbmc.log("[ravenbooks] %s" % msg, xbmc.LOGINFO)


def notify(msg, ms=4000):
    xbmcgui.Dialog().notification("Raven Books", msg, xbmcgui.NOTIFICATION_INFO, ms)


# ---------- story files ----------

def list_stories():
    """Return [(file_name, display_title)] in numbered order."""
    if not os.path.isdir(STORIES_DIR):
        return []
    out = []
    for name in sorted(os.listdir(STORIES_DIR)):
        if not name.lower().endswith(".txt"):
            continue
        title = os.path.splitext(name)[0]
        title = re.sub(r"^\d+_", "", title).replace("_", " ")
        out.append((name, title))
    return out


def read_story(name):
    path = os.path.join(STORIES_DIR, os.path.basename(name))
    with open(path, "r", encoding="utf-8") as f:
        return f.read()


# ---------- text chunking ----------

def split_long(piece, limit):
    """Split an over-long sentence at commas/spaces so each part fits."""
    parts = []
    while len(piece) > limit:
        cut = max(piece.rfind(", ", 0, limit), piece.rfind("; ", 0, limit))
        if cut < limit // 2:
            cut = piece.rfind(" ", 0, limit)
        if cut <= 0:
            cut = limit
        parts.append(piece[:cut + 1].strip())
        piece = piece[cut + 1:].strip()
    if piece:
        parts.append(piece)
    return parts


def make_chunks(text, limit=MAX_CHARS):
    text = text.replace("\r", "")
    chunks = []
    for para in re.split(r"\n\s*\n", text):
        para = " ".join(para.split())
        if not para:
            continue
        sentences = re.split(r"(?<=[.!?])\s+", para)
        current = ""
        for s in sentences:
            for piece in split_long(s, limit):
                if current and len(current) + 1 + len(piece) > limit:
                    chunks.append(current)
                    current = piece
                else:
                    current = (current + " " + piece).strip()
        if current:
            chunks.append(current)
    return chunks


# ---------- text to speech ----------

def tts_to_file(text, path):
    url = ("https://translate.google.com/translate_tts?ie=UTF-8&client=tw-ob&tl=en&q="
           + urllib.parse.quote(text))
    req = urllib.request.Request(url, headers={"User-Agent": USER_AGENT})
    last_err = None
    for attempt in range(3):
        try:
            with urllib.request.urlopen(req, timeout=20) as resp:
                data = resp.read()
            if data:
                with open(path, "wb") as f:
                    f.write(data)
                return True
        except (urllib.error.URLError, OSError) as e:
            last_err = e
            time.sleep(1.5 * (attempt + 1))
    log("TTS failed: %s" % last_err)
    return False


def chunk_path(slug, idx):
    return os.path.join(CACHE_DIR, "%s_%04d.mp3" % (slug, idx))


def ensure_chunk(slug, idx, text):
    path = chunk_path(slug, idx)
    if os.path.exists(path) and os.path.getsize(path) > 0:
        return path
    if tts_to_file(text, path):
        return path
    return None


# ---------- plugin screens ----------

def build_url(**params):
    return BASE_URL + "?" + urllib.parse.urlencode(params)


def show_menu():
    stories = list_stories()
    if not stories:
        notify("No stories found in resources/stories", 6000)
    for name, title in stories:
        li = xbmcgui.ListItem(label=title)
        li.setInfo("music", {"title": title, "artist": "Trevor Ambrose"})
        li.setProperty("IsPlayable", "false")
        xbmcplugin.addDirectoryItem(HANDLE, build_url(action="play", story=name), li, False)
    li = xbmcgui.ListItem(label="[Clear saved audio]")
    xbmcplugin.addDirectoryItem(HANDLE, build_url(action="clear"), li, False)
    xbmcplugin.endOfDirectory(HANDLE)


def play_story(name):
    title = re.sub(r"^\d+_", "", os.path.splitext(name)[0]).replace("_", " ")
    slug = os.path.splitext(name)[0]
    try:
        chunks = make_chunks(read_story(name))
    except OSError as e:
        notify("Could not read story: %s" % e, 6000)
        xbmcplugin.endOfDirectory(HANDLE, succeeded=False)
        return
    if not chunks:
        notify("Story is empty", 4000)
        xbmcplugin.endOfDirectory(HANDLE, succeeded=False)
        return

    xbmcvfs.mkdirs(CACHE_DIR)
    notify("Preparing audio for %s ..." % title, 3000)

    playlist = xbmc.PlayList(xbmc.PLAYLIST_MUSIC)
    playlist.clear()

    def add_to_playlist(idx, path):
        li = xbmcgui.ListItem(label="%s (part %d/%d)" % (title, idx + 1, len(chunks)))
        li.setInfo("music", {"title": "%s (part %d/%d)" % (title, idx + 1, len(chunks)),
                             "artist": "Trevor Ambrose", "album": title})
        playlist.add(path, li)

    next_idx = 0
    while next_idx < min(START_CHUNKS, len(chunks)):
        path = ensure_chunk(slug, next_idx, chunks[next_idx])
        if not path:
            notify("Audio conversion failed. Check your internet connection.", 6000)
            xbmcplugin.endOfDirectory(HANDLE, succeeded=False)
            return
        add_to_playlist(next_idx, path)
        next_idx += 1

    player = xbmc.Player()
    player.play(playlist)
    # Tell Kodi this item has been handled, then keep converting in the background.
    xbmcplugin.endOfDirectory(HANDLE, succeeded=False)

    monitor = xbmc.Monitor()
    # wait for playback to actually start
    waited = 0.0
    while not player.isPlaying() and waited < 15 and not monitor.abortRequested():
        monitor.waitForAbort(0.25)
        waited += 0.25

    failures = 0
    while next_idx < len(chunks) and not monitor.abortRequested():
        if not player.isPlaying():
            break  # user stopped playback
        path = ensure_chunk(slug, next_idx, chunks[next_idx])
        if path:
            add_to_playlist(next_idx, path)
            next_idx += 1
            failures = 0
        else:
            failures += 1
            if failures >= 3:
                notify("Stopped converting: connection problem", 6000)
                break
        monitor.waitForAbort(0.1)
    if next_idx >= len(chunks):
        log("all %d chunks queued for %s" % (len(chunks), title))


def clear_cache():
    removed = 0
    if os.path.isdir(CACHE_DIR):
        for n in os.listdir(CACHE_DIR):
            if n.endswith(".mp3"):
                try:
                    os.remove(os.path.join(CACHE_DIR, n))
                    removed += 1
                except OSError:
                    pass
    notify("Removed %d saved audio files" % removed)
    xbmcplugin.endOfDirectory(HANDLE, succeeded=False)


def router():
    params = dict(urllib.parse.parse_qsl(sys.argv[2][1:])) if len(sys.argv) > 2 else {}
    action = params.get("action")
    if action == "play":
        play_story(params.get("story", ""))
    elif action == "clear":
        clear_cache()
    else:
        show_menu()


if __name__ == "__main__":
    router()
